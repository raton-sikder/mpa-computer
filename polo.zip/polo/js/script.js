jQuery(function($){
"use strict"
$(document).ready(function(){

$(window).scroll(function () {

  if($(window).scrollTop() > 52) {
    $("#menubar").addClass('fixed');
  } else {
    $("#menubar").removeClass('fixed');
  }

});


$("#search-btn").on("click",function(){
    $(".search-popup").css({"opacity":"1","visibility":"visible"});
});
$(".popup-overlay").on("click",function(){
    $(".search-popup").css({"opacity":"0","visibility":"hidden"});
});
$(".popup-close").on("click",function(){
    $(".search-popup").css({"opacity":"0","visibility":"hidden"});
});

// owlCarousel
$('.st-carousel').each(function() {
    var owlCarousel = $(this),
    loop            = owlCarousel.data('loop'),
    center          = owlCarousel.data('center'),
    items           = owlCarousel.data('items'),
    margin          = owlCarousel.data('margin'),
    autoplay        = owlCarousel.data('autoplay'),
    hoverpause      = owlCarousel.data('hoverpause'),
    autoplayTimeout = owlCarousel.data('autoplay-timeout'),
    smartSpeed      = owlCarousel.data('smart-speed'),
    dots            = owlCarousel.data('dots'),
    nav             = owlCarousel.data('nav'),
    navSpeed        = owlCarousel.data('nav-speed'),

    xsItems         = owlCarousel.data('xs-items'),
    xsNav           = owlCarousel.data('xs-nav'),
    xsDots          = owlCarousel.data('xs-dots'),

    sm2Items        = owlCarousel.data('sm2-items'),
    sm2Nav          = owlCarousel.data('sm2-nav'),
    sm2Dots         = owlCarousel.data('sm2-dots'),

    smItems         = owlCarousel.data('sm-items'),
    smNav           = owlCarousel.data('sm-nav'),
    smDots          = owlCarousel.data('sm-dots'),

    mdItems         = owlCarousel.data('md-items'),
    mdNav           = owlCarousel.data('md-nav'),
    mdDots          = owlCarousel.data('md-dots'),

    lgItems         = owlCarousel.data('lg-items'),
    lgNav           = owlCarousel.data('lg-nav'),
    lgDots          = owlCarousel.data('lg-dots'),

    xlItems         = owlCarousel.data('xl-items'),
    xlNav           = owlCarousel.data('xl-nav'),
    xlDots          = owlCarousel.data('xl-dots');

    owlCarousel.owlCarousel({
        loop: (loop ? true : false),
        center: (center ? true : false),
        items: (items ? items : 4),
        lazyLoad: true,
        margin: (margin ? margin : 0),
        autoplay: (autoplay ? true : false),
        autoplayHoverPause: (hoverpause ? true : false),
        autoplayTimeout: (autoplayTimeout ? autoplayTimeout : 1000),
        smartSpeed: (smartSpeed ? smartSpeed : 250),
        dots: (dots ? true : false),
        nav: (nav ? true : false),
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        navSpeed: (navSpeed ? true : false),
        responsiveClass: true,
        responsive: {
            0: {
                items: (xsItems ? xsItems : 1),
                nav: (xsNav ? true : false),
                dots: (xsDots ? true : false),
            },
            481: {
                items: (sm2Items ? sm2Items : 2),
                nav: (sm2Nav ? true : false),
                dots: (sm2Dots ? true : false),
            },
            576: {
                items: (smItems ? smItems : 3),
                nav: (smNav ? true : false),
                dots: (smDots ? true : false),
            },
            768: {
                items: (mdItems ? mdItems : 4),
                nav: (mdNav ? true : false),
                dots: (mdDots ? true : false),
            },
            992: {
                items: (lgItems ? lgItems : 5),
                nav: (lgNav ? true : false),
                dots: (lgDots ? true : false),
            },
            1201: {
                items: (xlItems ? xlItems : 6),
                nav: (xlNav ? true : false),
                dots: (xlDots ? true : false),
            }
        }
    });
});

// WOW JS
new WOW().init();


$('#photo-gallery').owlCarousel({
    autoplay: false,
    smartSpeed: 400,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    loop:true,
    margin:0,
    nav: true,
    dots: false,
    navText:['<span class="fas fa-angle-left"></span>','<span class="fas fa-angle-right"></span>'],
    responsiveClass:true,
    responsive:{
        0:{
            items:1
        },
        576:{
            items:2
        },
        768:{
            items:3
        },
        992:{
            items:4
        },
        1200:{
            items:4
        }
    }
});

$('.video-popup').magnificPopup({
  type: 'iframe',
  tLoading: 'Loading image #%curr%...',
  mainClass: 'mfp-img-mobile'
});

$('.img-popup').magnificPopup({
  type: 'image',
  tLoading: 'Loading image #%curr%...',
  mainClass: 'mfp-img-mobile'
});

$('.gallery-popup').magnificPopup({
  type: 'image',
  delegate: '.gallery-item',
  tLoading: 'Loading image #%curr%...',
  mainClass: 'mfp-img-mobile',
  gallery: {
    enabled: true,
    navigateByImgClick: true,
    preload: [0,1] // Will preload 0 - before current, and 1 after the current image
  }
});

// Isotop init
var gridfilter = $('#product-filter-content');
    if(gridfilter.length){
    $('#product-filter-content').imagesLoaded(function() {
        $('#product-filter-nav').on('click', 'button', function() {
            var filterValue = $(this).attr('data-filter');
            $grid.isotope({
                filter: filterValue
            });
        });
        var $grid = $('#product-filter-content').isotope({
            itemSelector: '.product-filter-item',
            percentPosition: true,
            masonry: {
                columnWidth: '.product-filter-item',
            }
        });
    });
}
if ($('#product-filter-nav button').length) {
    var projectfiler = $('#product-filter-nav button');
        if(projectfiler.length){
        $('#product-filter-nav button').on('click', function(event) {
            $(this).siblings('.active').removeClass('active');
            $(this).addClass('active');
            event.preventDefault();
        });
    }
}

/* scroll-top section */

$(window).scroll(function(){
if($(this).scrollTop() > 40){
  $('#topBtn').fadeIn();
} else{
  $('#topBtn').fadeOut();
}
});

$("#topBtn").click(function(){
$('html ,body').animate({scrollTop : 0},800);
});


});


});